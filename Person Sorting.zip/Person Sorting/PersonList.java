import java.util.Iterator;
import java.util.NoSuchElementException;

public class PersonList implements Iterable<Person> {

    private PersonNode firstNameNode;
    private PersonNode firstAgeNode;

    /**
     * Constructs a new PersonList.
     */
    public PersonList() {
        firstNameNode = null;
        firstAgeNode = null;
    }

    /**
     * Adds a Person to the PersonList and sorts them by name and age.
     *
     * @param p Person
     */
    public void add(Person p) {
        PersonNode newNode = new PersonNode(p);

        addName(newNode);
        addAge(newNode);
    }

    /**
     * Adds a PersonNode to the PersonList sorted by name.
     *
     * @param p PersonNode
     */
    private void addName(PersonNode p) {
        if (firstNameNode == null || firstNameNode.info.compareTo(p.info) >= 0) {
            p.nextNameNode = firstNameNode;
            firstNameNode = p;
        } else {
            PersonNode curName = firstNameNode;

            while (curName.nextNameNode != null && curName.nextNameNode.info.compareTo(p.info) < 0) {
                curName = curName.nextNameNode;
            }
            p.nextNameNode = curName.nextNameNode;
            curName.nextNameNode = p;
        }
    }

    /**
     * Adds a PersonNode to the PersonList sorted by age.
     *
     * @param p PersonNode
     */
    private void addAge(PersonNode p) {
        if (firstAgeNode == null || firstAgeNode.info.compareToAge(p.info) >= 0) {
            p.nextAgeNode = firstAgeNode;
            firstAgeNode = p;
        } else {
            PersonNode curAge = firstAgeNode;

            while (curAge.nextAgeNode != null && curAge.nextAgeNode.info.compareToAge(p.info) < 0) {
                curAge = curAge.nextAgeNode;
            }
            p.nextAgeNode = curAge.nextAgeNode;
            curAge.nextAgeNode = p;
        }
    }

    /**
     * Returns an Iterator for the PersonList sorted by name.
     *
     * @return NameIterator
     */
    @Override
    public Iterator<Person> iterator() {
        return new NameIterator();
    }

    /**
     * Represents a PersonNode in the PersonList.
     */
    private class PersonNode implements Comparable<PersonNode> {

        private Person info;
        private PersonNode nextNameNode;
        private PersonNode nextAgeNode;

        /**
         * Constructs a new PersonNode with the given Person.
         *
         * @param p Person
         */
        public PersonNode(Person p) {
            info = p;
        }

        /**
         * Returns true if the PersonNode has a next PersonNode sorted by name.
         *
         * @return boolean
         */
        public boolean hasNextName() {
            return this.nextNameNode != null;
        }

        /**
         * Returns true if the PersonNode has a next PersonNode sorted by age.
         *
         * @return boolean
         */
        public boolean hasNextAge() {
            return this.nextAgeNode != null;
        }

        /**
         * Returns the next PersonNode sorted by name.
         *
         * @return PersonNode
         */
        public PersonNode getNextName() {
            return nextNameNode;
        }

        /**
         * Returns the next PersonNode sorted by age.
         *
         * @return PersonNode
         */
        public PersonNode getNextAge() {
            return nextAgeNode;
        }

        /**
         * Compares this PersonNode to another PersonNode by name and age.
         *
         * @param p PersonNode
         * @return int
         */
        public int compareTo(PersonNode p) {
            int nameNodeDiff = this.info.compareTo(p.info);
            if (nameNodeDiff != 0) {
                return nameNodeDiff;
            } else {
                return this.compareToAge(p);
            }
        }

        /**
         * Compares this PersonNode to another PersonNode by age.
         *
         * @param p PersonNode
         * @return int
         */
        public int compareToAge(PersonNode p) {
            int ageNodeDiff = this.info.compareToAge(p.info);
            if (ageNodeDiff != 0) {
                return ageNodeDiff;
            } else {
                return this.compareTo(p);
            }

        }
    }

    /**
     * Represents an Iterator for the PersonList sorted by name.
     */
    private class NameIterator implements Iterator<Person> {

        private PersonNode curNode;

        /**
         * Constructs a new NameIterator.
         */
        public NameIterator() {
            curNode = firstNameNode;
        }

        /**
         * Returns true if the PersonList has a next Person sorted by name.
         *
         * @return boolean
         */
        public boolean hasNext() {
            return curNode.nextNameNode != null;
        }

        /**
         * Returns the next Person sorted by name.
         *
         * @return Person
         */
        public Person next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            curNode = curNode.nextNameNode;
            return curNode.info;
        }
    }

    /**
     * Returns an Iterator for the PersonList sorted by age.
     *
     * @return AgeIterator
     */
    public Iterator<Person> iteratorByAge() {
        return new AgeIterator();
    }

    /**
     * Represents an Iterator for the PersonList sorted by age.
     */
    private class AgeIterator implements Iterator<Person> {

        private PersonNode curNode;

        /**
         * Constructs a new AgeIterator.
         */
        public AgeIterator() {
            curNode = firstAgeNode;

        }

        /**
         * Returns true if the PersonList has a next Person sorted by age.
         *
         * @return boolean
         */
        public boolean hasNext() {
            return curNode.nextAgeNode != null;
        }

        /**
         * Returns the next Person sorted by age.
         *
         * @return Person
         */
        public Person next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            Person currentInfo = curNode.info;
            curNode = curNode.nextAgeNode;
            return currentInfo;
        }

    }
}
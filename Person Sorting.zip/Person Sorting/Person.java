public class Person implements Comparable<Person> {

    private String name;
    private int age;

    /**
     * Constructs a new Person with the given name and age.
     *
     * @param name String
     * @param age int
     */
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    /**
     * Returns a String representation of this Person.
     *
     * @return String
     */
    @Override
    public String toString() {
        return name + ", " + age;
    }

    /**
     * Compares this Person to another Person by name and age.
     *
     * @param p Person
     * @return int
     */
    @Override
    public int compareTo(Person p) {
        int nameDiff = this.name.compareTo(p.name);
        if (nameDiff != 0) {
            return nameDiff;
        } else {
            return this.compareToAge(p);
        }
    }

    /**
     * Compares this Person to another Person by age.
     *
     * @param p Person
     * @return int
     */
    public int compareToAge(Person p) {
        int ageDiff = this.age - p.age;
        if (ageDiff != 0) {
            return ageDiff;
        } else {
            return this.compareTo(p);
        }
    }
}

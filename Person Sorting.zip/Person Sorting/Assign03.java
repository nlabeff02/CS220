/**
 * Program description: This program reads data from a text file called "people.txt" which contains
 * name and age data separated by a comma. It then constructs a PersonList using this data and prints
 * the list first in alphabetical order by name and then in numerical order by age.
 *
 * Author: Nathan LaBeff
 * Date last modified: April 06, 2023
 */

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;

public class Assign03 {

    public static void main(String[] args) {
        // Load data from text file and create PersonList
        PersonList pl = loadData();

        // Print PersonList in alphabetical order by name
        System.out.println("** PRINTING LIST BY NAME **\n");
        printListByName(pl);

        // Print PersonList in numerical order by age
        System.out.println("\n\n** PRINTING LIST BY AGE **\n");
        printListByAge(pl);

    }

    /**
     * Reads in data from "people.txt" and constructs a PersonList using this data.
     *
     * @return PersonList
     */
    private static PersonList loadData() {
        try {
            FileReader fr = new FileReader("./people.txt");
            BufferedReader br = new BufferedReader(fr);
            String line = br.readLine();

            PersonList list = new PersonList();

            // Parse each line to get name and age, then add a new Person to the PersonList
            while (line != null) {
                Scanner lineScan = new Scanner(line);
                int split = line.indexOf(",");
                String name = line.substring(0, split);
                int age = Integer.parseInt(line.substring(split + 2));

                Person nameAge = new Person(name, age);
                list.add(nameAge);

                line = br.readLine();
            }

            br.close();
            return list;

        } catch (IOException E) {
            System.out.println("FiLe wAs nOt fOuNd!!!!");
        }
        return null;
    }

    /**
     * Prints the list in alphabetical order by name.
     *
     * @param pl PersonList
     */
    private static void printListByName(PersonList pl) {
        Iterator<Person> printNameIterator = pl.iterator();
        while (printNameIterator.hasNext()) {
            System.out.println(printNameIterator.next());
        }
    }

    /**
     * Prints the list in numerical order by age.
     *
     * @param pl PersonList
     */
    private static void printListByAge(PersonList pl) {
        Iterator<Person> printAgeIterator = pl.iteratorByAge();
        while (printAgeIterator.hasNext()) {
            System.out.println(printAgeIterator.next());
        }
    }
}

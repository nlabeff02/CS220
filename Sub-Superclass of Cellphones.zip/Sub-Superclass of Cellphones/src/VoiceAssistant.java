import java.io.FileNotFoundException;

public interface VoiceAssistant {

    public void processSpeech(String speech) throws SpeechNotUnderstoodException;

    public void saySomething(String speech) throws SpeechNotUnderstoodException, FileNotFoundException;

}

import java.io.*;

public abstract class Smartphone implements Logger, VoiceAssistant{

    protected double batteryCapacity;
    protected double currentBatteryAmount;
    protected String model;

    Smartphone(double batteryCapacity, String model){
        batteryCapacity = 100;

    }
    public abstract void takePicture();

    public abstract void talkOnPhone(int mins);

    public void charge(){
       try {
           writeToLogFile("" + "charging");
       }catch (FileNotFoundException e){

       }
    }


    @Override
    public void processSpeech(String speech) throws SpeechNotUnderstoodException {
        try {
            if (speech.equals("picture")) {
                takePicture();
            }
            if (speech.contains("talk")) {
                String[] substrings = speech.split(" ");
                talkOnPhone(Integer.parseInt(substrings[1]));
            } else {
                writeToLogFile("\"" + speech + "\"");
                throw(new SpeechNotUnderstoodException("\"" + speech + "\"" + "is not understood by the voice assistant for " + model + " phones."));
            }
        } catch (SpeechNotUnderstoodException e) {

        } catch (FileNotFoundException f){
            f.printStackTrace();
        }
    }

    @Override
    public void saySomething(String speech) throws SpeechNotUnderstoodException, FileNotFoundException {

        System.out.println("'" + speech + "'");

    }

    @Override
    public String toString() {
       return "Phone{" +
                "BatteryCapacity = " + batteryCapacity +
                ", currentBatteryAmount=" + currentBatteryAmount +
                "%, model='" + model + '\'' +
                '}';
    }
    private static boolean isInt(String s) { try {
        Integer.parseInt(s);
    } catch(NumberFormatException e) {
        return false;
        }
        return true;
    }
    @Override
    public void writeToLogFile(String message) throws FileNotFoundException {
        try{
            FileOutputStream fos = new FileOutputStream("./" + model + ".bin", true);
            DataOutputStream dos = new DataOutputStream(fos);
            if(isInt(message) == true){
                dos.writeChars(message);
            }else{
                dos.writeBytes(message);
            }


        }catch (IOException e){
            e.printStackTrace();
        }


    }
}

import java.io.*;

public abstract class TV implements Logger {

    protected int currentChannel = 2;
    protected int currentVolume = 10;
    protected String model;

    public TV(String model){
        this.model = model;
    }

    @Override
    public void writeToLogFile(String message) {
        try{
            FileWriter fw = new FileWriter("./" + model + ".txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.println(message);
            bw.flush();
            bw.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public void incChannel() {
        if(currentChannel <= 49) {
            currentChannel++;
            writeToLogFile("'Increasing channel to" + currentChannel + "' // assuming " + currentChannel + " is the new current channel");
        } else if (currentChannel > 49) {
            currentChannel = currentChannel;
            writeToLogFile("'cannot increase channel' " + "// cannot increase channel higher than 50");
        }
    }
    public void decChannel() {
        if(currentChannel > 2){
            currentChannel --;
            writeToLogFile("'Decreasing channel to" + currentChannel + "' // assuming " + currentChannel + " is the new current channel");
        } else if (currentChannel > 49) {
            currentChannel = currentChannel;
            writeToLogFile("'cannot decrease channel' " + "// cannot decrease channel lower than 1");
        }
    }
    public void changeChannel(int channel){
        if( 1 <= channel && channel <= 50) {
            currentChannel = channel;
            writeToLogFile("'changing channel to " + currentChannel + "' // assuming " + currentChannel + " is the new channel");
        } else if (channel < 1 || channel > 50){
            currentChannel = currentChannel;
            writeToLogFile("'cannot change channel to' " + channel + "' // channels range from 1-50.");
        }

    }

    public void incVolume(){
        if(currentVolume <= 49){
            currentVolume ++;
            writeToLogFile("'Increasing volume to" + currentVolume + "' // assuming " + currentVolume + " is the new current volume");
        } else if (currentVolume > 49) {
            currentVolume = currentVolume;
            writeToLogFile("'cannot increase volume' " + "// cannot increase volume higher than 50");
        }
    }
    public void decVolume(){
        if(currentVolume > 2) {
            currentVolume --;
            writeToLogFile("'Decreasing volume to" + currentVolume + "' // assuming " + currentVolume + " is the new current volume");
        } else if (currentVolume < 2) {
            currentVolume = currentVolume;
            writeToLogFile("'cannot decrease volume' " + "// cannot decrease volume lower than 1");
        }

    }

    @Override
    public String toString() {
        return "TV{" +
                "currentChannel=" + currentChannel +
                ", currentVolume=" + currentVolume +
                ", model='" + model + '\'' +
                '}';
    }

}

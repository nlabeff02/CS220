import java.io.FileNotFoundException;

public class P10 extends Smartphone{

    P10() {
        super(2900, "p10");
        model = "p10";
        batteryCapacity = 2900;

    }

    @Override
    public void takePicture() {
        System.out.println(model + ": Taking picture at 1500 x 1125 pixels.");
        batteryCapacity = batteryCapacity - 150;
        currentBatteryAmount = (batteryCapacity/2900) * 100;
        try {
            writeToLogFile("picture");

        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
    }

    @Override
    public void talkOnPhone(int mins) {
        System.out.println("Talking on phone for " + mins + "minutes.");
        batteryCapacity = (batteryCapacity - (mins * 10));
        currentBatteryAmount = (batteryCapacity/2900) * 100;
        try {
            writeToLogFile("talk: .\"" + mins + ".\"");
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
    }
    public void takeVideo(int seconds){
        System.out.println(model + ": Taking a video on phone for " + seconds + "seconds");
        batteryCapacity = (batteryCapacity - (seconds * 5));
        currentBatteryAmount = (batteryCapacity/2900) * 10;
        try {
            writeToLogFile("video: .\"" + seconds + ".\"");
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
    }

    @Override
    public void processSpeech(String speech) throws SpeechNotUnderstoodException {
        try {
            if (speech.equals("picture")) {
                takePicture();
            }
            if (speech.contains("talk")) {
                String[] substrings = speech.split(" ");
                talkOnPhone(Integer.parseInt(substrings[1]));
            }
            if(speech.contains("video")) {
                String[] substrings = speech.split(" ");
                takeVideo(Integer.parseInt(substrings[1]));
            }else {
                writeToLogFile("\"" + speech + "\"");
                throw(new SpeechNotUnderstoodException("\"" + speech + "\"" + "is not understood by the voice assistant for " + model + " phones."));
            }
        } catch (SpeechNotUnderstoodException e) {

        } catch (FileNotFoundException f){
            f.printStackTrace();
        }
    }

}

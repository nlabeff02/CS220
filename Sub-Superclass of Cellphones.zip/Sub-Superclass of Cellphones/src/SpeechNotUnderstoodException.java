public class SpeechNotUnderstoodException extends Exception{
//This is an exception that when the speech isn't one of the options, it will say it is not an option.
    public SpeechNotUnderstoodException(String message){
        super(message);


    }
}


import java.io.*;
public class NebulaTV extends TV implements VoiceAssistant{
//this class is an extension of the TV class and allows the NebulaTV to understand speech input from the user.
    public NebulaTV() {
        super("Nebula");
    }

    public void saySomething(String speech) throws SpeechNotUnderstoodException {
        System.out.println(speech);
        writeToLogFile("\"speech\"");

    }
//The method below takes in speech and understands what is being said to make sure that their statement causes action.
    public void processSpeech(String speech) throws SpeechNotUnderstoodException {
       try {
           if (speech.equals("increase channel")) {
               incChannel();
               saySomething(speech);
           }
           if (speech.equals("decrease channel")) {
               decChannel();
               saySomething(speech);
           }
           if (speech.equals("increase volume")) {
               incVolume();
               saySomething(speech);
           }
           if (speech.equals("decrease volume")) {
               decVolume();
               saySomething(speech);
           }
           if (speech.contains("change channel to")) {
               String[] changeCh = speech.split(" ");
               int channel = Integer.parseInt(changeCh[3]);
               changeChannel(channel);
               saySomething(speech);
           }
       }catch (SpeechNotUnderstoodException e){
           System.out.println("'" + speech + "' is not understood by the voice assistant for " + model + "TVs.");
       }
    }
}

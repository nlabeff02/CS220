import java.io.FileNotFoundException;

public interface Logger {

    public void writeToLogFile(String message) throws FileNotFoundException;

}

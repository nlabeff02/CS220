
public class StarTV extends TV{
//The starTV is an extension of the TV class and offers no other features than that of the TV class.
    public StarTV() {
        super("Star");
    }


}

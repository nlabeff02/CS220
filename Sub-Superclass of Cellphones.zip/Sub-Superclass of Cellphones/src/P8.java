import java.io.FileNotFoundException;

public class P8 extends Smartphone {

    P8() {
        super(2000, "p8");
        model = "p8";
        batteryCapacity = 2000;
    }

    @Override
    public void takePicture() {
        System.out.println(model + ": Taking picture at 1200 x 900 pixels.");
        batteryCapacity = batteryCapacity - 200;
        currentBatteryAmount = (batteryCapacity/2000) * 100;
       try {
           writeToLogFile("picture");

       }catch (FileNotFoundException e){
           e.printStackTrace();
       }
    }

    @Override
    public void talkOnPhone(int mins) {
        System.out.println("Talking on phone for " + mins + "minutes.");
        batteryCapacity = (batteryCapacity - (mins * 20));
        currentBatteryAmount = (batteryCapacity/2000) * 100;
       try {
           writeToLogFile("talk: .\"" + mins + ".\"");
       }catch (FileNotFoundException e){
            e.printStackTrace();
       }

    }
}

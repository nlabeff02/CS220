/**
 * Class HandleInput:
 * This class is used to hold static methods that can 
 * be used to get input from the user, and validate that 
 * the user entered correct values.
 *
 * Last Modified: [DATE LAST MODIFIED]
 * Author: [YOUR NAME HERE]
 */

import java.util.Scanner;

public class HandleInput {
	// This class has no attributes

	/**
	 * Constructor for the HandleInput class. Since there are no attributes, this
	 * constructor does not do anything. YOU SHOULD NOT MODIFY THIS CONSTRUCTOR!!!!
	 */
	public HandleInput() {
	}

	/**
	 * This method will print a menu, and then read the user's menu selection and
	 * return that selection back to the caller. YOU SHOULD NOT MODIFY THIS METHOD,
	 * IT IS PROVIDED FOR YOU!!
	 * 
	 *
	 * @param scan
	 *            The Scanner variable must be passed from the caller, because it is
	 *            expected that only a single Scanner has been created for accessing
	 *            the console.
	 * @return The character that corresponds to the menu item selected by the user.
	 */
	public static char getMenu(Scanner scan) {
		String line;
		boolean done = false;
		char selection;

		// Print out the menu items
		System.out.println("\nCalendar Menu:");
		System.out.println("\tc - Check calendar for appointments");
		System.out.println("\ta - Add a new calendar appointment");
		System.out.println("\tl - List appointments");
		System.out.println("\tr - Remove appointment");
		System.out.println("\tx - eXit the calendar program");

		do {
			// Print out the prompt
			System.out.print("Enter choice: ");

			// Get the user input, force it to lower case, and
			// get the first character
			line = scan.nextLine();
			line = line.toLowerCase();
			selection = line.charAt(0);

			// Validate the input
			if (selection == 'c' || selection == 'a' || selection == 'l' || selection == 'r' || selection == 'x') {
				done = true;
			} else {
				// Print an error message if they entered a bad input
				System.out.println("ERROR: bad menu item, please select from the list above");
			}
		} while (!done);
		System.out.println();

		// return the character of the selected menu item
		return selection;
	}

	/**
	 * This method will prompt the user to enter an appointment description, and
	 * then return whatever they typed. You don't need to do any validity checking
	 * of their input, since they could type anything for an appointment
	 * description.
	 *
	 * @param scan
	 *            The Scanner variable for accessing console input.
	 * @return The String appointment description entered by the user.
	 */
	public static String getDescription(Scanner scan) {
		/* TODO - write this method */
		return null;
	}

	/**
	 * This method will verify whether a value is a valid day value. Days are
	 * integers 0 through 364, where 0 corresponds to Jan 1, and 365 corresponds to
	 * Dec 31.
	 *
	 * @param day
	 *            The day value that is being checked.
	 * @return true if the day is a valid value, false if it is not.
	 */
	public static boolean verifyDay(int day) {
		/* TODO - write this method */
		return false;
	}

	/**
	 * This method will verify whether a value is a valid hour value. Hours are
	 * integers 0 through 23, where 0 corresponds to midnight, and 23 corresponds to
	 * 11pm.
	 *
	 * @param hour
	 *            The hour value that is being checked.
	 * @return true if the hour is a valid value, false if it is not.
	 */
	public static boolean verifyHour(int hour) {
		/* TODO - write this method */
		return false;
	}

	/**
	 * This method will prompt the user to enter a day. Their input must be validity
	 * checked by using the verifyDay() method from above. If a bad value is
	 * entered, an error message should be printed and the user should be prompted
	 * again (and until they enter a correct value). The day they enter must then be
	 * returned to the caller.
	 *
	 * @param scan
	 *            The Scanner variable for accessing console input.
	 * @return The day entered by the user. Must be a value between 0 and 364.
	 */
	public static int getDay(Scanner scan) {
		/* TODO - write this method */
		return 0;
	}

	/**
	 * This method will prompt the user to enter an hour. Their input must be
	 * validity checked by using the verifyHour() method from above. If a bad value
	 * is entered, an error message should be printed and the user should be
	 * prompted again (and until they enter a correct value). The hour they enter
	 * must then be returned to the caller.
	 *
	 * @param scan
	 *            The Scanner variable for accessing console input.
	 * @return The hour entered by the user. Must be a value between 0 and 23.
	 */
	public static int getHour(Scanner scan) {
		/* TODO - write this method */
		return 0;
	}
}

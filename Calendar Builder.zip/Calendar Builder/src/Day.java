/**
 * Class Day: This class is used to represent one day of a schedule. The data is
 * an array of boolean values that represent whether an appointment is scheduled
 * for a particular hour of the day. There is also a description that is
 * associated with each hour of the day - saved in an array of Strings.
 *
 * Last Modified: [DATE LAST MODIFIED]
 * Author: [YOUR NAME HERE]
 */

public class Day {
	// Attributes

	// There are 24 hours in a day, so this
	// array should have 24 elements. If an
	// element is true, that means an appointment
	// is scheduled during that hour. If it is
	// false, then there is no appointment scheduled
	// during that hour.
	private boolean[] isBusy;

	// This also should have 24 elements, one
	// for each hour of the day. If an appointment
	// is scheduled for an hour, then this array
	// should hold a String description of the
	// appointment.
	private String[] appointmentDescription;

	/**
	 * Constructor for the Day class. This should allocate memory for the attribute
	 * arrays, and should initialize each hour to have no appointments.
	 * 
	 */
	public Day() {
		/* TODO - write this constructor */
	}

	/**
	 * This method should return whether or not there is an appointment scheduled
	 * for a particular time of this day.
	 *
	 * @param hour
	 *            The hour during this day whose status is being checked.
	 * @return true if there is an appointment scheduled during the requested hour,
	 *         false if there is not.
	 */
	public boolean checkTime(int hour) {
		/* TODO - write this method */
		return false;
	}

	/**
	 * This method should return whether or not there is an appointment scheduled at
	 * any hour of this day.
	 *
	 * @return true if there is an appointment scheduled during any hour of this
	 *         day, false if there are no appointments for this entire day.
	 */
	public boolean checkDay() {
		/* TODO - write this method */
		return false;
	}

	/**
	 * This method should return the appointment description for the appointment at
	 * the given time of this day.
	 *
	 * @param hour
	 *            The hour during this day whose appointment description should be
	 *            returned.
	 * @return If an appointment is scheduled at the given hour, then the
	 *         appointment description should be returned, otherwise the text "No
	 *         appointment scheduled" should be returned.
	 */
	public String getDescription(int hour) {
		/* TODO - write this method */
		return null;
	}

	/**
	 * This method should add a new appointment to the given hour for this day. This
	 * method should modify the isBusy and appointmentDescription for the given day
	 * only if there is not already an appointment for the given hour.
	 *
	 * @param hour
	 *            The hour during this day for which an appointment should be made.
	 * @param description
	 *            The text description of the new appointment.
	 * @return false if there is already an appointment scheduled during the given
	 *         hour (the previous appointment information should not be modified),
	 *         and true if adding the appointment was successful (there was no
	 *         previous appointment).
	 */
	public boolean addAppointment(int hour, String description) {
		/* TODO - write this method */
		return false;
	}

	/**
	 * This method should remove an appointment for a given hour for this day. There
	 * should be no effect if there was not an appointment scheduled in the first
	 * place.
	 *
	 * @param hour
	 *            The hour during this day for which an appointment removed.
	 */
	public void removeAppointment(int hour) {
		/* TODO - write this method */
	}

	/**
	 * This method should generate a String of all appointment times and
	 * descriptions for a given hour for this day. There should be no print
	 * statements in this method, only the code to create a String.
	 *
	 * @return A String whose text is one line for each appointment on this day.
	 *         Each line should have the appointment time and the appointment
	 *         description. See the program description for the exact formatting.
	 */
	public String toString() {
		/* TODO - write this method */
		return null;
	}
}

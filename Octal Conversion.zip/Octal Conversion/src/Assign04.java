
public class Assign04 {

	private static int weight = 200;

	public static void main(String[] args) {

		System.out.println("** OCTAL CONVERSION **");
		System.out.println("0 in octal:" + octalConversion(0));
		System.out.println("1 in octal:" + octalConversion(1));
		System.out.println("5 in octal:" + octalConversion(5));
		System.out.println("7 in octal:" + octalConversion(7));
		System.out.println("8 in octal:" + octalConversion(8));
		System.out.println("9 in octal:" + octalConversion(9));
		System.out.println("15 in octal:" + octalConversion(15));
		System.out.println("16 in octal:" + octalConversion(16));
		System.out.println("17 in octal:" + octalConversion(17));
		System.out.println("255 in octal:" + octalConversion(255));
		
		System.out.println("\n** WORD PALINDROME **");
		String line = "Bores are people that say that people are bores.";
		System.out.println(line+": "+isWordPalindrome(line));
		line = "";
		System.out.println(line+"\t\t\t\t\t\t: "+isWordPalindrome(line));
		line = "say";
		System.out.println(line+"\t\t\t\t\t\t: "+isWordPalindrome(line));
		line = "car ride ride car";
		System.out.println(line+"\t\t\t\t: "+isWordPalindrome(line));
		line = "FALL LEAVES AFTER LEAVES FALL";
		System.out.println(line+"\t\t\t: "+isWordPalindrome(line));
		line = "taco cat";
		System.out.println(line+"\t\t\t\t\t\t: "+isWordPalindrome(line));

		System.out.println("\n** WEIGHT ON **");
		System.out.println("0, 0: " + weightOn(0,0));
		System.out.println("1, 0: " + weightOn(1,0));
		System.out.println("2, 1: " + weightOn(2,1));
		System.out.println("4, 2: " + weightOn(4,2));
		System.out.println();
		
		System.out.println("\n** INT TO ENGLISH **");
		System.out.println(convertToEnglish(0));
		System.out.println(convertToEnglish(3));
		System.out.println(convertToEnglish(10));
		System.out.println(convertToEnglish(33));
		System.out.println(convertToEnglish(100));
		System.out.println(convertToEnglish(333));
		System.out.println(convertToEnglish(1000));
		System.out.println(convertToEnglish(3333));
		System.out.println(convertToEnglish(10000));
		System.out.println(convertToEnglish(33333));
		System.out.println(convertToEnglish(100000));
		System.out.println(convertToEnglish(333333));
		System.out.println(convertToEnglish(1000000));
		System.out.println(convertToEnglish(3333333));
		System.out.println(convertToEnglish(10000000));
		System.out.println(convertToEnglish(33333333));
		System.out.println(convertToEnglish(100000000));
		System.out.println(convertToEnglish(333333333));
		System.out.println(convertToEnglish(987654321));
	}
	
	/**
	 * Converts an int from base 10 (decimal) to a string in base 8 (octal).
	 * 
	 * @param n The base 10 number to convert.
	 * @return The octal string value.
	 */
	private static String octalConversion(int n) {
		//TODO write me
	}

	/**
	 * Determines whether or not the given string is a word palindrome.
	 * 
	 * @param line The given string.
	 * @return True if its a word palindrome, false if not.
	 */
	private static boolean isWordPalindrome(String line) {
		//TODO write me
	}
	
	/**
	 * Calculates the weight being carried by the person at row, col.
	 * 
	 * @param row The row position of the person.
	 * @param col The column position of the person.
	 * @return A double representing the amount of weight the person at row col is carrying.
	 */
	private static double weightOn(int row, int col) {
		//TODO write me
	}
	
	/**
	 * Converts the given int into an English sentence.
	 * num will always be less than one billion.
	 * 
	 * @param num An int greater or equal to zero and less than one billion.
	 * @return
	 */
	private static String convertToEnglish(int num) {
		//TODO write me
	}

}
